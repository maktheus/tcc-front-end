
  # AgentBench Platform Design Handoff

  This is a code bundle for AgentBench Platform Design Handoff. The original project is available at https://www.figma.com/design/x7xLGUczXJXV5DfNFcXb2c/AgentBench-Platform-Design-Handoff.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  